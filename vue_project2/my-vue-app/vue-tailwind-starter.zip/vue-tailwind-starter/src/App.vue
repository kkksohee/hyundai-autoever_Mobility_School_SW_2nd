<template>
  <div class="min-h-screen bg-gray-100 p-6 text-center">
    <h1 class="text-3xl font-bold text-blue-600">Vue 3 + Tailwind CSS Starter</h1>
    <HelloWorld msg="안녕하세요! Tailwind와 함께하는 Vue 3입니다." />
  </div>
</template>

<script setup>
import HelloWorld from './components/HelloWorld.vue'
</script>
